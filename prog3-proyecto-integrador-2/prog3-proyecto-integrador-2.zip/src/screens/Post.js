import { View, Text } from 'react-native'
import React from 'react'

export default function Post() {
  return (
    <View>
      <Text>Feed</Text>
    </View>
  )
}